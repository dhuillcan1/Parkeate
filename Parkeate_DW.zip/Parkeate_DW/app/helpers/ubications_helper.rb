module UbicationsHelper
end
