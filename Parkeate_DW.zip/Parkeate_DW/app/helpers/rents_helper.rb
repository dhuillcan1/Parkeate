module RentsHelper
end
