class Ubication < ApplicationRecord
end
