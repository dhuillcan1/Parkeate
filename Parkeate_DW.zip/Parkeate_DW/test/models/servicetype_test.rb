require 'test_helper'

class ServicetypeTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
