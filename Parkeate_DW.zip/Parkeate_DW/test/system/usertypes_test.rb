require "application_system_test_case"

class UsertypesTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit usertypes_url
  #
  #   assert_selector "h1", text: "Usertype"
  # end
end
