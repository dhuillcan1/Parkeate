require "application_system_test_case"

class ParkingsTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit parkings_url
  #
  #   assert_selector "h1", text: "Parking"
  # end
end
